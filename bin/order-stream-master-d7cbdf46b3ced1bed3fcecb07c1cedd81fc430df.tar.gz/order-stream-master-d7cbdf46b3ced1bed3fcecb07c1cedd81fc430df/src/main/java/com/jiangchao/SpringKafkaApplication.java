package com.jiangchao; /**
 * Created by Administrator on 2017/9/11.
 */
import com.jiangchao.kafka.consumer.HouseKeeperReceiver;
import com.jiangchao.kafka.producer.Sender;
import com.jiangchao.kafka.stream.FreqTopology;
import com.jiangchao.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaApplication {

    public static void main(String[] args) {
       ApplicationContext ctx =  SpringApplication.run(SpringKafkaApplication.class, args);
       /**
       Order order = new Order("51930371830910247",15, 100, 1, 1084581, 43747,1505975905649L, 576873, 1505975931605L );
       int loop = 10;
       Sender sender = ctx.getBean(Sender.class);
       while (loop-- > 0) {
           order.setPrice(loop);
           sender.send(order);
       }
       **/

       //FreqTopology topology = ctx.getBean(FreqTopology.class);
       //topology.run();
        HouseKeeperReceiver houseKeeperReceiver = ctx.getBean(HouseKeeperReceiver.class);
        (new Thread( houseKeeperReceiver)).start();
    }
}
