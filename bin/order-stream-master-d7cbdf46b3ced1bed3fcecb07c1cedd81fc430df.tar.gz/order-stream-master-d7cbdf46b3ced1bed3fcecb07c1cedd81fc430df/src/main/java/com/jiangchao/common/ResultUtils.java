package com.jiangchao.common;

import com.jiangchao.enums.ResultCode;

/**
 * Created by Administrator on 2017/9/27.
 */
public class ResultUtils {
    public static Result success(Object data) {
       return new Result<>(ResultCode.SUCCESS, data);
    }
    public static Result fail(ResultCode resultCode, String msg) {
       Result<Object> result = new Result<>(resultCode);
       result.setMsg(msg);
       return result;
    }
    public static Result fail(ResultCode resultCode) {
       return new Result(resultCode);
    }
}
