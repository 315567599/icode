package com.jiangchao.controller;

import com.jiangchao.common.Result;
import com.jiangchao.common.ResultUtils;
import com.jiangchao.enums.ResultCode;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by Administrator on 2017/9/27.
 */
@ControllerAdvice
@ResponseBody
public class ExceptionHandleAdvice {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandleAdvice.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result handleArgumentInValidExcetpion(MethodArgumentNotValidException e) {
        List<ObjectError> errors = e.getBindingResult().getAllErrors();
        String tips = "参数不合法";
        if (errors.size() > 0) {
           tips = errors.get(0).getDefaultMessage();
        }
        return ResultUtils.fail(ResultCode.PARAM_INVALID, tips);
    }

    @ExceptionHandler(Exception.class)
    public Result handleException(Exception e, HttpServletRequest request) {
        LOGGER.error("url={} | Body={}", request.getRequestURI(), e.toString());
        return ResultUtils.fail(ResultCode.WEAK_NET_WORK);
    }
}
