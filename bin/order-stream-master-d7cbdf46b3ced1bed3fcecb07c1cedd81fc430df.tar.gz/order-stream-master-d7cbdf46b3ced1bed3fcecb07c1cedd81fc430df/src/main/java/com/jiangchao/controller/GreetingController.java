package com.jiangchao.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jiangchao.common.Result;
import com.jiangchao.enums.ResultCode;
import com.jiangchao.model.Order;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.concurrent.atomic.AtomicLong;
import java.util.Map;
import java.util.HashMap;

import com.jiangchao.model.User;

import javax.validation.Valid;

/**
 * Created by Administrator on 2017/9/26.
 */
@RestController
public class GreetingController {
    private static final String template = "Hello, %s";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/greeting")
    public Map<String, Object> greeting(@RequestParam(value="name", defaultValue = "world") String name) {
        Map<String, Object> map = new HashMap<>();
        map.put("counter", counter.incrementAndGet());
        map.put("message", String.format(template, name));
        return map;
    }

    @RequestMapping("/user")
    public Map<String, Object> user() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object>userData = mapper.readValue(new File("C:\\Users\\Administrator\\Desktop\\kafkajson\\target\\user.json"), Map.class);
            String json = mapper.writeValueAsString(userData);
            System.out.println(userData);
            System.out.println(json);
            return userData;
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
        return null;
    }

    @RequestMapping("/login")
    public Result login(@RequestBody @Valid User user) {
       return new Result(ResultCode.SUCCESS, user);
    }

    @RequestMapping("/testjson")
    public String testJson(@RequestBody String data) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Order order = mapper.readValue(data, Order.class);
            System.out.println(order.toString());
            return order.toString();
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
        return null;
    }

}
