package com.jiangchao.dao;

import com.jiangchao.model.HouseKeeper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Created by Administrator on 2017/11/4.
 */

@Component
public class HouseKeeperRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public boolean insert(HouseKeeper houseKeeper) {
       int row = jdbcTemplate.update(
               "INSERT INTO t_house_keeper(amount, mid, sourceType, userId, timestamp, created_at) VALUES (?,?,?,?,?,?)",
               houseKeeper.getAmount(),
               houseKeeper.getMid(),
               houseKeeper.getSourceType(),
               houseKeeper.getUserId(),
               houseKeeper.getTimestamp(),
               System.currentTimeMillis()
       );

       return row > 0 ? true : false;
    }
}
