package com.jiangchao.dao;

import com.jiangchao.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by Administrator on 2017/9/11.
 */
@Component
public class OrderRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public boolean insert(Order order) {
        int row = jdbcTemplate.update(
                "INSERT INTO t_order(orderId, goods, orderType, price, cityId, serviceId, userId, payTime, communityId, createTime, createdTs) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                order.getOrderId(),
                order.getJsonGoods(),
                order.getOrderType(),
                order.getPrice(),
                order.getCityId(),
                order.getServiceId(),
                order.getUserId(),
                order.getPayTime(),
                order.getCommunityId(),
                order.getCreateTime(),
                (int)(System.currentTimeMillis()/1000)
        );

        return row > 0 ? true : false;
    }

    public List<Order> getOrders() {
        String sql ="SELECT * FROM t_order";
        List<Order> results = jdbcTemplate.query(sql, new RowMapper<Order>() {
            @Override
            public Order mapRow(ResultSet resultSet, int i) throws SQLException {
                Order order = new Order(
                        resultSet.getString("orderId"),
                        null,
                        resultSet.getInt("orderType"),
                        resultSet.getInt("price"),
                        resultSet.getInt("cityId"),
                        resultSet.getInt("serviceId"),
                        resultSet.getInt("userId"),
                        resultSet.getLong("payTime"),
                        resultSet.getInt("communityId"),
                        resultSet.getLong("createTime")
                );
                return order;
            }
        });

        return results;
    }
}
