package com.jiangchao.kafka.consumer;

/**
 * Created by Administrator on 2017/11/3.
 */
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.jiangchao.dao.HouseKeeperRepository;
import com.jiangchao.model.HouseKeeper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.Runnable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
public class HouseKeeperReceiver implements Runnable {
   private static final String TOPIC = "housekeeper_risk_control";
   private static final String GROUP_ID = "big-eye";

   private static final Logger LOGGER = LoggerFactory.getLogger(HouseKeeperReceiver.class);
   private final AtomicBoolean closed = new AtomicBoolean(false);
   KafkaConsumer<String, String> consumer ;

   @Value("${kafka.bootstrap-servers}")
   private String bootstrapServers;

   @Autowired
   HouseKeeperRepository houseKeeperRepository;

   @Bean
   public Properties kafkaConfig() {
      Properties props = new Properties();
      props.put("bootstrap.servers", bootstrapServers);
      props.put("group.id", GROUP_ID);
      props.put("enable.auto.commit", "true");
      props.put("auto.commit.interval.ms", "1000");
      props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
      props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
      return  props;
   }

   //thread task
   public void run() {
      Properties props = kafkaConfig();
      consumer = new KafkaConsumer<String, String>(props);
      ObjectMapper mapper = new ObjectMapper();

      try {
         consumer.subscribe(Arrays.asList(TOPIC));
         while (true) {
            ConsumerRecords<String, String> records = consumer.poll(3);
            for (ConsumerRecord<String, String> record : records) {
               System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(), record.value());
               HouseKeeper houseKeeper = mapper.readValue(record.value(), HouseKeeper.class);
               if ( !houseKeeperRepository.insert(houseKeeper)) {
                  LOGGER.error("Save Record failed, Value: " + record.value());
               };
            }
         }
      }
      catch (WakeupException e) {
      }
      catch (IOException e) {
         e.printStackTrace();
      }
      finally {
         consumer.close();
      }
   }

   public void shutdown() {
      closed.set(true);
      consumer.wakeup();
   }
}
