package com.jiangchao.kafka.stream;

/**
 * Created by Administrator on 2017/9/11.
 */

import org.apache.kafka.streams.KeyValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.jiangchao.model.Order;
import org.apache.kafka.streams.processor.Processor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.KeyValueStore;

public class FreqProcessor implements Processor<String, String> {
   private static final Logger LOGGER = LoggerFactory.getLogger(FreqProcessor.class);
   private ProcessorContext context;
   private KeyValueStore<String, Integer> kvStore;

   @SuppressWarnings("unchecked")
   @Override
   public void init(ProcessorContext context) {
      this.context = context;
      this.context.schedule(2000);
      this.kvStore = (KeyValueStore<String, Integer>) context.getStateStore("Counts");
   }

   @Override
   public void process(String key, String order) {
      LOGGER.info("order processing ...", order.toString());
   }

   @Override
   public void punctuate(long timestamp) {
      KeyValueIterator<String, Integer> iter = this.kvStore.all();
      while (iter.hasNext()) {
         KeyValue<String, Integer> entry = iter.next();
         context.forward(entry.key, entry.value.toString());
      }
      iter.close();
      context.commit();
   }

   @Override
   public void close() {
   }
}
