package com.jiangchao.kafka.stream;

/**
 * Created by Administrator on 2017/9/11.
 */

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.*;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.processor.TopologyBuilder;
import org.apache.kafka.streams.state.Stores;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.jiangchao.kafka.stream.FreqProcessor;
import java.util.Properties;

@Component
public class FreqTopology {
    @Value("${kafka.bootstrap-servers}")
    private String bootstrapServers;

    public void run() {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-order-processor");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");

        TopologyBuilder builder = new TopologyBuilder();
        builder.addSource("Source", "json.t")
        .addProcessor("Process", FreqProcessor::new, "Source")
                .addStateStore(Stores.create("Counts").withStringKeys().withIntegerValues().inMemory().build(), "Process")
                .addSink("SINK", "count", new StringSerializer(), new IntegerSerializer(), "Process");

        KafkaStreams stream = new KafkaStreams(builder, props);
        stream.start();


    }
}
