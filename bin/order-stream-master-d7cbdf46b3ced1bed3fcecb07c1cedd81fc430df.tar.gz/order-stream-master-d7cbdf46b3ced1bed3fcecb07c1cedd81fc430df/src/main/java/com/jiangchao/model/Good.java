package com.jiangchao.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by Administrator on 2018/1/2.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Good {
    private int activityId;
    private int goodsId;
    private int num;
    private int originalPrice;
    private int goodsPrice;

    public Good() {
        super();
    }

    public Good(int activityId, int goodsId, int num, int originalPrice, int goodsPrice) {
       this.activityId = activityId;
       this.goodsId = goodsId;
       this.num = num;
       this.originalPrice = originalPrice;
       this.goodsPrice = goodsPrice;
    }

    public int getActivityId() {
        return activityId;
    }
    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }
    public int getGoodsId() {
        return goodsId;
    }
    public void setGoodsId(int goodsId) {
       this.goodsId = goodsId;
    }
    public int getNum() {
        return num;
    }
    public void setNum(int num) {
       this.num = num;
    }
    public int getOriginalPrice() {
        return originalPrice;
    }
    public void setOriginalPrice(int originalPrice) {
       this.originalPrice = originalPrice;
    }
    public int getGoodsPrice() {
        return goodsPrice;
    }
    public void setGoodsPrice(int goodsPrice) {
       this.goodsPrice = goodsPrice;
    }

    @Override
    public String toString() {
        return "Good [" +
                "activityID=" + activityId
                + ", goodId=" + goodsId
                + ", num=" + num
                + ",originalPrice="+ originalPrice
                + ",goodsPrice="+ goodsPrice
                + "]";
    }
}
