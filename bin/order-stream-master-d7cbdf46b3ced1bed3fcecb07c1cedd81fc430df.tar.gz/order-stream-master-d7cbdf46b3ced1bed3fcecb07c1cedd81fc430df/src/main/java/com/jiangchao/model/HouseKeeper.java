package com.jiangchao.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by Administrator on 2017/11/4.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class HouseKeeper {
    private String amount;
    private String mid;
    private int sourceType;
    private int userId;
    private long timestamp;

    public HouseKeeper() {
        super();
    }

    public HouseKeeper(String amount, String mid, int sourceType, int userId, long timestamp) {
       this.amount = amount;
       this.mid = mid;
       this.sourceType = sourceType;
       this.userId = userId;
       this.timestamp = timestamp;
    }

    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
       this.amount = amount;
    }
    public String getMid() {
        return mid;
    }
    public void setMid(String mid) {
       this.mid = mid;
    }
    public int getSourceType() {
        return sourceType;
    }
    public void setSourceType(int sourceType) {
       this.sourceType = sourceType;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
       this.userId = userId;
    }
    public long getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(long timestamp) {
       this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "HouseKeeper [" +
                "amount=" + amount
                + ", mid=" + mid
                + ", sourceType=" + sourceType
                + ",userId="+ userId
                + ",timestamp="+ timestamp
                + "]";
    }
}
