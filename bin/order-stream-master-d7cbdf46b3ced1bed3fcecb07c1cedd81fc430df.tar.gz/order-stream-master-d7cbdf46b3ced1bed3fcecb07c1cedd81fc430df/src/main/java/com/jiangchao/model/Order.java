package com.jiangchao.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Order {
    private String orderId;
    private List<Good> goodsArray;
    private int orderType;
    private int price;
    private int cityId;
    private int serviceId;
    private int userId;
    private long payTime;
    private int communityId;
    private long createTime;

    public Order() {
        super();
    }

    public Order(String orderId, List<Good> goodsArray, int orderType, int price, int cityId, int serviceId, int userId, long payTime, int communityId, long createTime) {
        this.orderId = orderId;
        this.goodsArray = goodsArray;
        this.orderType = orderType;
        this.price = price;
        this.cityId = cityId;
        this.serviceId = serviceId;
        this.userId = userId;
        this.payTime = payTime;
        this.communityId = communityId;
        this.createTime = createTime;
    }

    public String getOrderId() {
        return  orderId;
    }
    public void setOrderId(String orderId) {
       this.orderId = orderId;
    }
    public List<Good> getGoodsArray() {
        return goodsArray;
    }
    public void setGoods(List<Good> goodsArray) {
       this.goodsArray = goodsArray;
    }
    public String getJsonGoods() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(goodsArray);
        } catch (JsonProcessingException e) {
            return "";
        }
    }
    public int getOrderType() {
        return orderType;
    }
    public void setOrderType(int orderType) {
       this.orderType = orderType;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
       this.price = price;
    }
    public int getCityId() {
        return cityId;
    }
    public void setCityId(int cityId) {
       this.cityId = cityId;
    }
    public int getServiceId() {
        return serviceId;
    }
    public void setServiceId(int serviceId) {
       this.serviceId = serviceId;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
       this.userId = userId;
    }
    public long getPayTime() {
        return payTime;
    }
    public void setPayTime(long payTime) {
       this.payTime = payTime;
    }
    public int getCommunityId() {
        return communityId;
    }
    public void setCommunityId(int communityId) {
       this.communityId = communityId;
    }
    public long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "Order [" +
                "uid=" + userId
                + ", orderID=" + orderId
                + ", goods=" + getJsonGoods()
                + ", mid=" + serviceId
                + ",price="+ price
                + "]";
    }
}
